### TinyToggle
## A simple feature toggle package.

# Usage
TODO
